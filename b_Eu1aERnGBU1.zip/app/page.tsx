"use client"

import { motion } from "framer-motion"
import { Sidebar } from "@/components/bess/sidebar"
import { TopNav } from "@/components/bess/top-nav"
import { KPICards } from "@/components/bess/kpi-cards"
import { EnergyFlow } from "@/components/bess/energy-flow"
import { ContainerHeatmap } from "@/components/bess/container-heatmap"
import { AlarmCenter } from "@/components/bess/alarm-center"
import { PredictiveAnalytics } from "@/components/bess/predictive-analytics"
import { AICopilot } from "@/components/bess/ai-copilot"
import { RealtimeMonitoring } from "@/components/bess/realtime-monitoring"

export default function BESSDashboard() {
  return (
    <div className="min-h-screen bg-background">
      {/* Animated Background Grid */}
      <div className="fixed inset-0 grid-background opacity-30 pointer-events-none" />
      
      {/* Ambient Glow Effects */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-glow-cyan/5 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-glow-purple/3 rounded-full blur-3xl pointer-events-none" />

      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="pl-[260px] min-h-screen">
        <TopNav />

        {/* Main Workspace */}
        <main className="p-6 space-y-6">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="w-1 h-8 bg-gradient-to-b from-primary to-glow-cyan rounded-full" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">System Overview</h1>
                <p className="text-sm text-muted-foreground">
                  Real-time monitoring dashboard • Last updated: {new Date().toLocaleTimeString()}
                </p>
              </div>
            </div>
          </motion.div>

          {/* KPI Cards */}
          <section>
            <KPICards />
          </section>

          {/* Energy Flow Visualization */}
          <section>
            <EnergyFlow />
          </section>

          {/* Container Heatmap */}
          <section>
            <ContainerHeatmap />
          </section>

          {/* Two Column Layout - Alarms & Analytics */}
          <section className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <AlarmCenter />
            <PredictiveAnalytics />
          </section>

          {/* AI Copilot */}
          <section>
            <AICopilot />
          </section>

          {/* Real-time Monitoring */}
          <section>
            <RealtimeMonitoring />
          </section>

          {/* Footer */}
          <motion.footer
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-center py-8 border-t border-border/50 mt-12"
          >
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <span>BESS Health Monitor</span>
              <span className="text-border">•</span>
              <span>AI-Powered Industrial Intelligence Platform</span>
              <span className="text-border">•</span>
              <span className="text-primary">v2.4.0</span>
            </div>
          </motion.footer>
        </main>
      </div>
    </div>
  )
}
