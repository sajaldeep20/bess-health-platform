"use client"

import { motion } from "framer-motion"
import { Battery, Home, Building2, Sun, Wind, Zap, ArrowRight } from "lucide-react"

export function EnergyFlow() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Energy Flow Visualization</h2>
          <p className="text-sm text-muted-foreground">Real-time power distribution across the grid</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-emerald/10 border border-glow-emerald/30">
          <motion.div
            className="w-2 h-2 rounded-full bg-glow-emerald"
            animate={{ scale: [1, 1.3, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <span className="text-xs font-medium text-glow-emerald">Live</span>
        </div>
      </div>

      <div className="relative h-64">
        {/* Background Grid */}
        <div className="absolute inset-0 grid-background rounded-xl opacity-30" />

        {/* Energy Sources */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 flex flex-col gap-6">
          <EnergyNode
            icon={Sun}
            label="Solar"
            value="125 MW"
            color="glow-amber"
          />
          <EnergyNode
            icon={Wind}
            label="Wind"
            value="89 MW"
            color="glow-cyan"
          />
        </div>

        {/* Battery Storage - Center */}
        <motion.div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          whileHover={{ scale: 1.05 }}
        >
          <div className="relative">
            <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-primary/20 to-glow-cyan/20 border-2 border-primary/50 flex flex-col items-center justify-center glow-blue">
              <Battery className="w-10 h-10 text-primary mb-2" />
              <span className="text-2xl font-bold text-foreground">87%</span>
              <span className="text-xs text-muted-foreground">245.8 MW</span>
            </div>
            {/* Charging Animation */}
            <motion.div
              className="absolute inset-0 rounded-2xl border-2 border-primary/50"
              animate={{
                boxShadow: [
                  "0 0 0 0 rgba(59, 130, 246, 0)",
                  "0 0 0 10px rgba(59, 130, 246, 0.1)",
                  "0 0 0 20px rgba(59, 130, 246, 0)",
                ],
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        </motion.div>

        {/* Consumers */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 flex flex-col gap-6">
          <EnergyNode
            icon={Building2}
            label="Industrial"
            value="156 MW"
            color="primary"
            reverse
          />
          <EnergyNode
            icon={Home}
            label="Residential"
            value="58 MW"
            color="glow-emerald"
            reverse
          />
        </div>

        {/* Flow Lines - Left */}
        <svg className="absolute left-[100px] top-1/2 -translate-y-1/2 w-[calc(50%-116px)] h-32" preserveAspectRatio="none">
          <defs>
            <linearGradient id="flowGradientLeft" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="100%" stopColor="#3B82F6" />
            </linearGradient>
          </defs>
          <motion.path
            d="M 0 40 Q 60 40 100 64 T 200 64"
            fill="none"
            stroke="url(#flowGradientLeft)"
            strokeWidth="2"
            strokeDasharray="8 4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.path
            d="M 0 88 Q 60 88 100 64 T 200 64"
            fill="none"
            stroke="#06B6D4"
            strokeWidth="2"
            strokeDasharray="8 4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
          />
        </svg>

        {/* Flow Lines - Right */}
        <svg className="absolute right-[100px] top-1/2 -translate-y-1/2 w-[calc(50%-116px)] h-32" preserveAspectRatio="none">
          <defs>
            <linearGradient id="flowGradientRight" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#10B981" />
            </linearGradient>
          </defs>
          <motion.path
            d="M 0 64 Q 40 64 100 40 T 200 40"
            fill="none"
            stroke="#3B82F6"
            strokeWidth="2"
            strokeDasharray="8 4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.path
            d="M 0 64 Q 40 64 100 88 T 200 88"
            fill="none"
            stroke="url(#flowGradientRight)"
            strokeWidth="2"
            strokeDasharray="8 4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
          />
        </svg>

        {/* Flow Particles */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-primary"
            style={{ top: `${35 + Math.random() * 30}%` }}
            animate={{
              x: [100, 300 + Math.random() * 100],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              delay: i * 0.5,
              ease: "linear",
            }}
          />
        ))}
      </div>

      {/* Stats Footer */}
      <div className="grid grid-cols-4 gap-4 mt-6 pt-6 border-t border-border/50">
        <StatItem label="Grid Import" value="45 MW" icon={ArrowRight} />
        <StatItem label="Grid Export" value="0 MW" icon={ArrowRight} />
        <StatItem label="Self-Consumption" value="92%" icon={Zap} />
        <StatItem label="Carbon Offset" value="1.2k tons" icon={Sun} />
      </div>
    </motion.div>
  )
}

function EnergyNode({
  icon: Icon,
  label,
  value,
  color,
  reverse = false,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  color: string
  reverse?: boolean
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className={`flex items-center gap-3 ${reverse ? "flex-row-reverse" : ""}`}
    >
      <div className={`p-3 rounded-xl bg-${color}/10 border border-${color}/30`}>
        <Icon className={`w-6 h-6 text-${color}`} />
      </div>
      <div className={reverse ? "text-right" : ""}>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-semibold text-foreground">{value}</p>
      </div>
    </motion.div>
  )
}

function StatItem({
  label,
  value,
  icon: Icon,
}: {
  label: string
  value: string
  icon: React.ComponentType<{ className?: string }>
}) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
        <Icon className="w-3 h-3" />
        <span className="text-xs">{label}</span>
      </div>
      <p className="font-semibold text-foreground">{value}</p>
    </div>
  )
}
