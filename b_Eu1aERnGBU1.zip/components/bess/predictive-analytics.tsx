"use client"

import { motion } from "framer-motion"
import {
  TrendingDown,
  Clock,
  AlertTriangle,
  Sparkles,
  Activity,
  Target,
} from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  ReferenceLine,
} from "recharts"

const sohData = [
  { month: "Jan", actual: 98.5, predicted: null },
  { month: "Feb", actual: 97.8, predicted: null },
  { month: "Mar", actual: 97.2, predicted: null },
  { month: "Apr", actual: 96.5, predicted: null },
  { month: "May", actual: 95.9, predicted: null },
  { month: "Jun", actual: 95.2, predicted: null },
  { month: "Jul", actual: 94.6, predicted: null },
  { month: "Aug", actual: 94.2, predicted: 94.2 },
  { month: "Sep", actual: null, predicted: 93.5 },
  { month: "Oct", actual: null, predicted: 92.8 },
  { month: "Nov", actual: null, predicted: 92.1 },
  { month: "Dec", actual: null, predicted: 91.4 },
]

const riskContainers = [
  { id: "C-087", rul: 18, risk: 92, trend: "declining" },
  { id: "C-023", rul: 24, risk: 78, trend: "declining" },
  { id: "C-134", rul: 30, risk: 65, trend: "stable" },
  { id: "C-091", rul: 36, risk: 52, trend: "stable" },
  { id: "C-045", rul: 42, risk: 38, trend: "improving" },
]

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass rounded-lg p-3 border border-glass-border">
        <p className="text-xs text-muted-foreground mb-2">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm font-medium" style={{ color: entry.color }}>
            {entry.name}: {entry.value?.toFixed(1)}%
          </p>
        ))}
      </div>
    )
  }
  return null
}

export function PredictiveAnalytics() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Activity className="w-5 h-5 text-glow-cyan" />
            Predictive Analytics & RUL
          </h2>
          <p className="text-sm text-muted-foreground">AI-powered health forecasting and remaining useful life predictions</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-purple/10 border border-glow-purple/30">
          <Sparkles className="w-4 h-4 text-glow-purple" />
          <span className="text-xs font-medium text-glow-purple">ML Model v2.4</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SOH Degradation Chart */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-foreground flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-glow-amber" />
              SOH Degradation Forecast
            </h3>
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1">
                <div className="w-3 h-0.5 bg-primary rounded" />
                <span className="text-muted-foreground">Actual</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-0.5 bg-glow-amber rounded border border-dashed border-glow-amber" />
                <span className="text-muted-foreground">Predicted</span>
              </div>
            </div>
          </div>

          <div className="h-64 bg-secondary/30 rounded-xl p-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sohData}>
                <defs>
                  <linearGradient id="sohActualGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3B82F6" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="sohPredictedGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#F59E0B" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#F59E0B" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="month" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: '#6B7280', fontSize: 11 }}
                />
                <YAxis 
                  domain={[88, 100]}
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fill: '#6B7280', fontSize: 11 }}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={90} stroke="#EF4444" strokeDasharray="3 3" strokeOpacity={0.5} />
                <Area
                  type="monotone"
                  dataKey="actual"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  fill="url(#sohActualGradient)"
                  name="Actual SOH"
                />
                <Area
                  type="monotone"
                  dataKey="predicted"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  fill="url(#sohPredictedGradient)"
                  name="Predicted SOH"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Confidence Band */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-glow-purple/5 border border-glow-purple/20">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-glow-purple" />
              <span className="text-sm text-muted-foreground">Prediction Confidence</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-32 h-2 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-glow-purple to-primary rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: "87%" }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
              <span className="text-sm font-medium text-foreground">87%</span>
            </div>
          </div>
        </div>

        {/* RUL Risk Rankings */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-foreground flex items-center gap-2">
              <Clock className="w-4 h-4 text-destructive" />
              Remaining Useful Life Rankings
            </h3>
            <span className="text-xs text-muted-foreground">Highest risk containers</span>
          </div>

          <div className="space-y-3">
            {riskContainers.map((container, index) => (
              <motion.div
                key={container.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ scale: 1.02 }}
                className="p-4 rounded-xl bg-secondary/30 border border-border/50 hover:border-primary/30 transition-smooth cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-bold text-muted-foreground">#{index + 1}</span>
                    <div>
                      <p className="font-medium text-foreground">{container.id}</p>
                      <p className="text-xs text-muted-foreground">RUL: {container.rul} months</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`
                      text-sm font-medium
                      ${container.risk >= 80 ? 'text-destructive' : 
                        container.risk >= 50 ? 'text-glow-amber' : 'text-glow-emerald'}
                    `}>
                      {container.risk}% Risk
                    </div>
                    <div className={`
                      text-xs capitalize
                      ${container.trend === 'declining' ? 'text-destructive' : 
                        container.trend === 'stable' ? 'text-glow-amber' : 'text-glow-emerald'}
                    `}>
                      {container.trend}
                    </div>
                  </div>
                </div>
                
                {/* Risk Bar */}
                <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full ${
                      container.risk >= 80 ? 'bg-gradient-to-r from-destructive to-glow-amber' :
                      container.risk >= 50 ? 'bg-gradient-to-r from-glow-amber to-glow-emerald' :
                      'bg-glow-emerald'
                    }`}
                    initial={{ width: 0 }}
                    animate={{ width: `${container.risk}%` }}
                    transition={{ duration: 0.8, delay: 0.2 * index }}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-3 gap-3 mt-4">
            <div className="text-center p-3 rounded-lg bg-destructive/10 border border-destructive/30">
              <p className="text-2xl font-bold text-destructive">3</p>
              <p className="text-xs text-muted-foreground">High Risk</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-glow-amber/10 border border-glow-amber/30">
              <p className="text-2xl font-bold text-glow-amber">12</p>
              <p className="text-xs text-muted-foreground">Medium Risk</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-glow-emerald/10 border border-glow-emerald/30">
              <p className="text-2xl font-bold text-glow-emerald">125</p>
              <p className="text-xs text-muted-foreground">Low Risk</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
