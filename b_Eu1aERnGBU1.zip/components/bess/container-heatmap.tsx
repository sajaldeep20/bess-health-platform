"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Box, AlertTriangle, Sparkles, X } from "lucide-react"
import { Button } from "@/components/ui/button"

// Generate mock container data
const generateContainers = () => {
  return Array.from({ length: 140 }, (_, i) => {
    const random = Math.random()
    let status: "healthy" | "warning" | "critical"
    let soh: number
    let soc: number
    let temp: number
    let anomaly = false

    if (random > 0.92) {
      status = "critical"
      soh = 60 + Math.random() * 15
      soc = 20 + Math.random() * 30
      temp = 45 + Math.random() * 10
      anomaly = Math.random() > 0.5
    } else if (random > 0.8) {
      status = "warning"
      soh = 75 + Math.random() * 10
      soc = 40 + Math.random() * 30
      temp = 35 + Math.random() * 10
      anomaly = Math.random() > 0.7
    } else {
      status = "healthy"
      soh = 90 + Math.random() * 10
      soc = 70 + Math.random() * 25
      temp = 25 + Math.random() * 8
    }

    return {
      id: `C-${String(i + 1).padStart(3, "0")}`,
      status,
      soh: Math.round(soh * 10) / 10,
      soc: Math.round(soc * 10) / 10,
      temp: Math.round(temp * 10) / 10,
      anomaly,
      row: Math.floor(i / 14) + 1,
      col: (i % 14) + 1,
    }
  })
}

const containers = generateContainers()

const statusColors = {
  healthy: {
    bg: "bg-glow-emerald/20",
    border: "border-glow-emerald/50",
    text: "text-glow-emerald",
    glow: "hover:shadow-[0_0_15px_rgba(16,185,129,0.4)]",
  },
  warning: {
    bg: "bg-glow-amber/20",
    border: "border-glow-amber/50",
    text: "text-glow-amber",
    glow: "hover:shadow-[0_0_15px_rgba(245,158,11,0.4)]",
  },
  critical: {
    bg: "bg-destructive/20",
    border: "border-destructive/50",
    text: "text-destructive",
    glow: "hover:shadow-[0_0_15px_rgba(239,68,68,0.4)]",
  },
}

export function ContainerHeatmap() {
  const [selectedContainer, setSelectedContainer] = useState<typeof containers[0] | null>(null)
  const [filter, setFilter] = useState<"all" | "healthy" | "warning" | "critical">("all")

  const filteredContainers = filter === "all" 
    ? containers 
    : containers.filter(c => c.status === filter)

  const stats = {
    healthy: containers.filter(c => c.status === "healthy").length,
    warning: containers.filter(c => c.status === "warning").length,
    critical: containers.filter(c => c.status === "critical").length,
    anomalies: containers.filter(c => c.anomaly).length,
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Box className="w-5 h-5 text-primary" />
            Container Health Heatmap
          </h2>
          <p className="text-sm text-muted-foreground">140 battery containers monitored in real-time</p>
        </div>
        <div className="flex items-center gap-3">
          {/* AI Anomaly Badge */}
          {stats.anomalies > 0 && (
            <motion.div
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-purple/10 border border-glow-purple/30"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="w-4 h-4 text-glow-purple" />
              <span className="text-xs font-medium text-glow-purple">
                {stats.anomalies} AI Anomalies
              </span>
            </motion.div>
          )}
          
          {/* Filter Buttons */}
          <div className="flex gap-1 p-1 bg-secondary/50 rounded-lg">
            {(["all", "healthy", "warning", "critical"] as const).map((f) => (
              <Button
                key={f}
                variant="ghost"
                size="sm"
                onClick={() => setFilter(f)}
                className={`text-xs capitalize ${filter === f ? "bg-secondary text-foreground" : "text-muted-foreground"}`}
              >
                {f === "all" ? "All" : `${f} (${stats[f]})`}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="flex gap-4 mb-6">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-glow-emerald" />
          <span className="text-xs text-muted-foreground">Healthy ({stats.healthy})</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-glow-amber" />
          <span className="text-xs text-muted-foreground">Warning ({stats.warning})</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-destructive" />
          <span className="text-xs text-muted-foreground">Critical ({stats.critical})</span>
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <div className="w-3 h-3 rounded-full border-2 border-glow-purple animate-pulse" />
          <span className="text-xs text-muted-foreground">AI Detected Anomaly</span>
        </div>
      </div>

      {/* Heatmap Grid */}
      <div className="relative">
        <div className="grid grid-cols-14 gap-1.5">
          {filteredContainers.map((container, index) => {
            const colors = statusColors[container.status]
            return (
              <motion.button
                key={container.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.002 }}
                whileHover={{ scale: 1.15, zIndex: 10 }}
                onClick={() => setSelectedContainer(container)}
                className={`
                  relative aspect-square rounded-md
                  ${colors.bg} ${colors.border} border
                  ${colors.glow}
                  transition-all duration-200
                  flex items-center justify-center
                  cursor-pointer
                `}
              >
                <span className="text-[8px] font-mono text-muted-foreground opacity-0 group-hover:opacity-100">
                  {container.id.split("-")[1]}
                </span>
                
                {/* Anomaly Indicator */}
                {container.anomaly && (
                  <motion.div
                    className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-glow-purple rounded-full border border-background"
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                )}
                
                {/* Critical Pulse */}
                {container.status === "critical" && (
                  <motion.div
                    className="absolute inset-0 rounded-md border-2 border-destructive"
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                )}
              </motion.button>
            )
          })}
        </div>

        {/* Row Labels */}
        <div className="absolute -left-6 top-0 flex flex-col gap-1.5">
          {Array.from({ length: 10 }, (_, i) => (
            <div key={i} className="aspect-square flex items-center justify-center text-[10px] text-muted-foreground">
              {i + 1}
            </div>
          ))}
        </div>
      </div>

      {/* Selected Container Detail */}
      <AnimatePresence>
        {selectedContainer && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="mt-6 p-4 rounded-xl bg-secondary/50 border border-border/50"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${statusColors[selectedContainer.status].bg} ${statusColors[selectedContainer.status].border} border`}>
                  <Box className={`w-5 h-5 ${statusColors[selectedContainer.status].text}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    Container {selectedContainer.id}
                    {selectedContainer.anomaly && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-glow-purple/10 text-glow-purple border border-glow-purple/30">
                        AI Anomaly
                      </span>
                    )}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Row {selectedContainer.row}, Column {selectedContainer.col}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedContainer(null)}
                className="h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-4 gap-4 mt-4">
              <MetricCard label="State of Health" value={`${selectedContainer.soh}%`} status={selectedContainer.status} />
              <MetricCard label="State of Charge" value={`${selectedContainer.soc}%`} status={selectedContainer.status} />
              <MetricCard label="Temperature" value={`${selectedContainer.temp}°C`} status={selectedContainer.temp > 40 ? "warning" : "healthy"} />
              <MetricCard 
                label="Status" 
                value={selectedContainer.status.charAt(0).toUpperCase() + selectedContainer.status.slice(1)} 
                status={selectedContainer.status} 
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

function MetricCard({
  label,
  value,
  status,
}: {
  label: string
  value: string
  status: "healthy" | "warning" | "critical"
}) {
  const colors = statusColors[status]
  return (
    <div className={`p-3 rounded-lg ${colors.bg} ${colors.border} border`}>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className={`font-semibold ${colors.text}`}>{value}</p>
    </div>
  )
}
