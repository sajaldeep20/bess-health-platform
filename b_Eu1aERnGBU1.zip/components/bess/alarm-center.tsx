"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  AlertTriangle,
  AlertCircle,
  Info,
  Search,
  Filter,
  Sparkles,
  Clock,
  Box,
  Thermometer,
  Zap,
  Battery,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const alarms = [
  {
    id: 1,
    severity: "critical",
    title: "High Temperature Alert",
    container: "C-087",
    message: "Cell temperature exceeded 52°C threshold",
    timestamp: "2 min ago",
    icon: Thermometer,
    aiSuggestion: "Recommend immediate power reduction and cooling system check",
  },
  {
    id: 2,
    severity: "critical",
    title: "SOC Imbalance Detected",
    container: "C-023",
    message: "Cell group variance exceeds 5% threshold",
    timestamp: "5 min ago",
    icon: Battery,
    aiSuggestion: "Initiate cell balancing procedure",
  },
  {
    id: 3,
    severity: "warning",
    title: "Communication Timeout",
    container: "C-112",
    message: "BMS communication lost for 30 seconds",
    timestamp: "12 min ago",
    icon: AlertCircle,
    aiSuggestion: "Check network connectivity and restart BMS controller",
  },
  {
    id: 4,
    severity: "warning",
    title: "Voltage Deviation",
    container: "C-045",
    message: "Cell voltage deviation of 0.15V detected",
    timestamp: "18 min ago",
    icon: Zap,
    aiSuggestion: "Monitor for 30 minutes, schedule maintenance if persists",
  },
  {
    id: 5,
    severity: "info",
    title: "Scheduled Maintenance Due",
    container: "C-067",
    message: "Preventive maintenance scheduled in 48 hours",
    timestamp: "1 hour ago",
    icon: Info,
    aiSuggestion: null,
  },
  {
    id: 6,
    severity: "warning",
    title: "Capacity Degradation",
    container: "C-091",
    message: "SOH dropped below 85% threshold",
    timestamp: "2 hours ago",
    icon: Battery,
    aiSuggestion: "Schedule deep discharge cycle and recalibration",
  },
  {
    id: 7,
    severity: "critical",
    title: "Ground Fault Detected",
    container: "C-134",
    message: "Insulation resistance below safe threshold",
    timestamp: "3 hours ago",
    icon: AlertTriangle,
    aiSuggestion: "Isolate container immediately and dispatch technician",
  },
]

const severityConfig = {
  critical: {
    bg: "bg-destructive/10",
    border: "border-destructive/30",
    text: "text-destructive",
    pill: "bg-destructive/20 text-destructive border-destructive/30",
    glow: "shadow-[0_0_20px_rgba(239,68,68,0.2)]",
  },
  warning: {
    bg: "bg-glow-amber/10",
    border: "border-glow-amber/30",
    text: "text-glow-amber",
    pill: "bg-glow-amber/20 text-glow-amber border-glow-amber/30",
    glow: "",
  },
  info: {
    bg: "bg-primary/10",
    border: "border-primary/30",
    text: "text-primary",
    pill: "bg-primary/20 text-primary border-primary/30",
    glow: "",
  },
}

export function AlarmCenter() {
  const [filter, setFilter] = useState<"all" | "critical" | "warning" | "info">("all")
  const [search, setSearch] = useState("")

  const filteredAlarms = alarms.filter((alarm) => {
    if (filter !== "all" && alarm.severity !== filter) return false
    if (search && !alarm.title.toLowerCase().includes(search.toLowerCase()) && 
        !alarm.container.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const stats = {
    critical: alarms.filter(a => a.severity === "critical").length,
    warning: alarms.filter(a => a.severity === "warning").length,
    info: alarms.filter(a => a.severity === "info").length,
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-glow-amber" />
            Alarm & Event Center
          </h2>
          <p className="text-sm text-muted-foreground">Real-time monitoring with AI-suggested actions</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Critical Alert Counter */}
          {stats.critical > 0 && (
            <motion.div
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-destructive/10 border border-destructive/30"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <motion.div
                className="w-2 h-2 rounded-full bg-destructive"
                animate={{ opacity: [1, 0.5, 1] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              />
              <span className="text-xs font-medium text-destructive">
                {stats.critical} Critical
              </span>
            </motion.div>
          )}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center gap-4 mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search alarms..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-secondary/50 border-border/50"
          />
        </div>
        <div className="flex gap-1 p-1 bg-secondary/50 rounded-lg">
          {(["all", "critical", "warning", "info"] as const).map((f) => (
            <Button
              key={f}
              variant="ghost"
              size="sm"
              onClick={() => setFilter(f)}
              className={`text-xs capitalize ${filter === f ? "bg-secondary text-foreground" : "text-muted-foreground"}`}
            >
              {f}
              {f !== "all" && (
                <span className="ml-1 text-muted-foreground">({stats[f]})</span>
              )}
            </Button>
          ))}
        </div>
      </div>

      {/* Alarm List */}
      <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
        <AnimatePresence>
          {filteredAlarms.map((alarm, index) => {
            const config = severityConfig[alarm.severity]
            const Icon = alarm.icon
            
            return (
              <motion.div
                key={alarm.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.01 }}
                className={`
                  p-4 rounded-xl border transition-smooth cursor-pointer
                  ${config.bg} ${config.border} ${config.glow}
                  hover:border-opacity-60
                `}
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className={`p-2 rounded-lg ${config.bg} border ${config.border}`}>
                    <Icon className={`w-5 h-5 ${config.text}`} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${config.pill}`}>
                        {alarm.severity.toUpperCase()}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {alarm.timestamp}
                      </span>
                    </div>
                    
                    <h3 className="font-medium text-foreground mb-1">{alarm.title}</h3>
                    
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <Box className="w-3 h-3" />
                      <span>{alarm.container}</span>
                      <span className="text-border">•</span>
                      <span>{alarm.message}</span>
                    </div>

                    {/* AI Suggestion */}
                    {alarm.aiSuggestion && (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-start gap-2 mt-3 p-2 rounded-lg bg-glow-purple/5 border border-glow-purple/20"
                      >
                        <Sparkles className="w-4 h-4 text-glow-purple shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-medium text-glow-purple mb-0.5">AI Suggestion</p>
                          <p className="text-xs text-muted-foreground">{alarm.aiSuggestion}</p>
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Action */}
                  <Button variant="ghost" size="icon" className="shrink-0">
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>

      {filteredAlarms.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No alarms match your filters</p>
        </div>
      )}
    </motion.div>
  )
}
