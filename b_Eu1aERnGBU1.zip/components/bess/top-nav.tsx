"use client"

import { motion } from "framer-motion"
import {
  Search,
  Wifi,
  WifiOff,
  Sparkles,
  Bell,
  User,
  Cpu,
  Database,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function TopNav() {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="sticky top-0 z-30 h-16 glass border-b border-glass-border"
    >
      <div className="h-full flex items-center justify-between px-6">
        {/* Search */}
        <div className="relative w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search containers, alarms, reports..."
            className="pl-10 bg-secondary/50 border-border/50 focus:border-primary/50 focus:bg-secondary transition-smooth"
          />
        </div>

        {/* Center - Status Indicators */}
        <div className="flex items-center gap-6">
          {/* Connection Status */}
          <motion.div
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-emerald/10 border border-glow-emerald/30"
            animate={{ opacity: [0.8, 1, 0.8] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <motion.div
              className="w-2 h-2 rounded-full bg-glow-emerald"
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
            <Wifi className="w-4 h-4 text-glow-emerald" />
            <span className="text-xs font-medium text-glow-emerald">SCADA Connected</span>
          </motion.div>

          {/* Runtime Status */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30">
            <Cpu className="w-4 h-4 text-primary" />
            <span className="text-xs font-medium text-primary">GPU Active</span>
          </div>

          {/* Database Status */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-cyan/10 border border-glow-cyan/30">
            <Database className="w-4 h-4 text-glow-cyan" />
            <span className="text-xs font-medium text-glow-cyan">TimescaleDB</span>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {/* AI Assistant Quick Action */}
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 bg-gradient-to-r from-primary/10 to-glow-purple/10 border-primary/30 hover:border-primary/50 hover:bg-primary/20 transition-smooth"
            >
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm">AI Copilot</span>
              <kbd className="ml-1 px-1.5 py-0.5 text-[10px] bg-secondary rounded text-muted-foreground">
                ⌘K
              </kbd>
            </Button>
          </motion.div>

          {/* Notifications */}
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <motion.span
                className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center font-medium"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                7
              </motion.span>
            </Button>
          </motion.div>

          {/* User Profile */}
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button variant="ghost" size="icon" className="rounded-full">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-glow-cyan flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            </Button>
          </motion.div>
        </div>
      </div>
    </motion.header>
  )
}
