"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import {
  Radio,
  Database,
  Cpu,
  Clock,
  Wifi,
  HardDrive,
  Activity,
} from "lucide-react"

const generateMetric = (base: number, variance: number) => {
  return (base + (Math.random() - 0.5) * variance).toFixed(1)
}

export function RealtimeMonitoring() {
  const [metrics, setMetrics] = useState({
    dataRate: "2.4",
    latency: "12",
    uptime: "99.97",
    activeQueries: "847",
    memoryUsage: "62",
    cpuUsage: "34",
  })

  const [telemetryPoints, setTelemetryPoints] = useState<number[]>([
    50, 52, 48, 55, 53, 51, 54, 52, 56, 53, 55, 52, 54, 51, 53, 55, 52, 54, 53, 55,
  ])

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics({
        dataRate: generateMetric(2.4, 0.4),
        latency: generateMetric(12, 4),
        uptime: "99.97",
        activeQueries: String(Math.floor(800 + Math.random() * 100)),
        memoryUsage: generateMetric(62, 8),
        cpuUsage: generateMetric(34, 10),
      })

      setTelemetryPoints((prev) => {
        const newPoints = [...prev.slice(1), 50 + Math.random() * 10]
        return newPoints
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Radio className="w-5 h-5 text-glow-emerald" />
            Real-time Telemetry
          </h2>
          <p className="text-sm text-muted-foreground">Live system metrics and streaming data</p>
        </div>
        <motion.div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-emerald/10 border border-glow-emerald/30"
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <motion.div
            className="w-2 h-2 rounded-full bg-glow-emerald"
            animate={{ opacity: [1, 0.5, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          />
          <span className="text-xs font-medium text-glow-emerald">Streaming</span>
        </motion.div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard
          icon={Activity}
          label="Data Rate"
          value={`${metrics.dataRate} GB/s`}
          color="primary"
        />
        <MetricCard
          icon={Clock}
          label="Latency"
          value={`${metrics.latency} ms`}
          color="glow-cyan"
        />
        <MetricCard
          icon={Wifi}
          label="System Uptime"
          value={`${metrics.uptime}%`}
          color="glow-emerald"
        />
        <MetricCard
          icon={Database}
          label="Active Queries"
          value={metrics.activeQueries}
          color="glow-amber"
        />
      </div>

      {/* Live Telemetry Stream */}
      <div className="bg-secondary/30 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-muted-foreground">Live Telemetry Stream</span>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-primary" />
              <span className="text-sm">
                CPU: <span className="text-primary font-medium">{metrics.cpuUsage}%</span>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-glow-cyan" />
              <span className="text-sm">
                Memory: <span className="text-glow-cyan font-medium">{metrics.memoryUsage}%</span>
              </span>
            </div>
          </div>
        </div>

        {/* Waveform Visualization */}
        <div className="h-24 flex items-end gap-0.5">
          {telemetryPoints.map((point, index) => (
            <motion.div
              key={index}
              className="flex-1 bg-gradient-to-t from-primary to-glow-cyan rounded-t"
              initial={{ height: 0 }}
              animate={{ height: `${point}%` }}
              transition={{ duration: 0.3 }}
            />
          ))}
        </div>

        {/* Connection Status */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50">
          <div className="flex items-center gap-6">
            <StatusIndicator label="SCADA Link" status="connected" />
            <StatusIndicator label="TimescaleDB" status="connected" />
            <StatusIndicator label="Redis Cache" status="connected" />
            <StatusIndicator label="ML Pipeline" status="processing" />
          </div>
          <div className="text-xs text-muted-foreground font-mono">
            Last sync: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </motion.div>
  )
}

function MetricCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  color: string
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={`p-4 rounded-xl bg-${color}/5 border border-${color}/20 hover:border-${color}/40 transition-smooth`}
    >
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 text-${color}`} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <motion.p
        className={`text-xl font-bold text-${color}`}
        key={value}
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        {value}
      </motion.p>
    </motion.div>
  )
}

function StatusIndicator({
  label,
  status,
}: {
  label: string
  status: "connected" | "disconnected" | "processing"
}) {
  const statusConfig = {
    connected: {
      color: "bg-glow-emerald",
      text: "text-glow-emerald",
      label: "Connected",
    },
    disconnected: {
      color: "bg-destructive",
      text: "text-destructive",
      label: "Disconnected",
    },
    processing: {
      color: "bg-glow-amber",
      text: "text-glow-amber",
      label: "Processing",
    },
  }

  const config = statusConfig[status]

  return (
    <div className="flex items-center gap-2">
      <motion.div
        className={`w-2 h-2 rounded-full ${config.color}`}
        animate={status === "processing" ? { opacity: [1, 0.5, 1] } : {}}
        transition={{ duration: 1, repeat: Infinity }}
      />
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  )
}
