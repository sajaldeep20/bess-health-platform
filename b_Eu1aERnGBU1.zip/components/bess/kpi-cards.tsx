"use client"

import { motion } from "framer-motion"
import {
  Battery,
  Zap,
  Heart,
  AlertTriangle,
  Activity,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import {
  AreaChart,
  Area,
  ResponsiveContainer,
} from "recharts"

const sparklineData = [
  { value: 65 }, { value: 72 }, { value: 68 }, { value: 75 }, { value: 82 },
  { value: 78 }, { value: 85 }, { value: 88 }, { value: 84 }, { value: 87 },
]

const kpiData = [
  {
    title: "System SOC",
    value: "87.4",
    unit: "%",
    icon: Battery,
    trend: "+2.3%",
    trendUp: true,
    color: "glow-emerald",
    gradient: "from-glow-emerald/20 to-transparent",
    chartColor: "#10B981",
  },
  {
    title: "Active Power",
    value: "245.8",
    unit: "MW",
    icon: Zap,
    trend: "+5.1%",
    trendUp: true,
    color: "primary",
    gradient: "from-primary/20 to-transparent",
    chartColor: "#3B82F6",
  },
  {
    title: "System SOH",
    value: "94.2",
    unit: "%",
    icon: Heart,
    trend: "-0.8%",
    trendUp: false,
    color: "glow-cyan",
    gradient: "from-glow-cyan/20 to-transparent",
    chartColor: "#06B6D4",
  },
  {
    title: "Active Alarms",
    value: "12",
    unit: "",
    icon: AlertTriangle,
    trend: "+4",
    trendUp: false,
    color: "glow-amber",
    gradient: "from-glow-amber/20 to-transparent",
    chartColor: "#F59E0B",
    alert: true,
  },
  {
    title: "Round-trip Efficiency",
    value: "92.7",
    unit: "%",
    icon: Activity,
    trend: "+1.2%",
    trendUp: true,
    color: "glow-purple",
    gradient: "from-glow-purple/20 to-transparent",
    chartColor: "#8B5CF6",
  },
]

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { y: 0, opacity: 1 },
}

export function KPICards() {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4"
    >
      {kpiData.map((kpi, index) => {
        const Icon = kpi.icon
        return (
          <motion.div
            key={kpi.title}
            variants={item}
            whileHover={{ scale: 1.02, y: -4 }}
            className={`relative group glass rounded-2xl p-5 border border-glass-border overflow-hidden transition-smooth hover:border-${kpi.color}/50`}
          >
            {/* Background Gradient */}
            <div className={`absolute inset-0 bg-gradient-to-br ${kpi.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
            
            {/* Glow Effect */}
            <div className={`absolute -top-20 -right-20 w-40 h-40 bg-${kpi.color}/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
            
            <div className="relative z-10">
              {/* Header */}
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-xl bg-${kpi.color}/10 border border-${kpi.color}/30`}>
                  <Icon className={`w-5 h-5 text-${kpi.color}`} />
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${kpi.trendUp ? 'text-glow-emerald' : 'text-destructive'}`}>
                  {kpi.trendUp ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {kpi.trend}
                </div>
              </div>

              {/* Value */}
              <div className="mb-2">
                <div className="flex items-baseline gap-1">
                  <motion.span
                    className="text-3xl font-bold text-foreground"
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.3 }}
                  >
                    {kpi.value}
                  </motion.span>
                  <span className="text-sm text-muted-foreground">{kpi.unit}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
              </div>

              {/* Sparkline */}
              <div className="h-12 mt-3">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={sparklineData}>
                    <defs>
                      <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={kpi.chartColor} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={kpi.chartColor} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke={kpi.chartColor}
                      strokeWidth={2}
                      fill={`url(#gradient-${index})`}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Alert Pulse */}
            {kpi.alert && (
              <motion.div
                className="absolute top-3 right-3 w-3 h-3 bg-glow-amber rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [1, 0.5, 1],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            )}
          </motion.div>
        )
      })}
    </motion.div>
  )
}
