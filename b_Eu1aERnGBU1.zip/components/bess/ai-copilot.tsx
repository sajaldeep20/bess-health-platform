"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Sparkles,
  Send,
  FileText,
  AlertTriangle,
  TrendingUp,
  Wrench,
  Bot,
  ChevronRight,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const quickActions = [
  {
    icon: FileText,
    label: "Generate Report",
    description: "Create a comprehensive system health report",
    color: "primary",
  },
  {
    icon: AlertTriangle,
    label: "Analyze Alarms",
    description: "AI analysis of recent alarm patterns",
    color: "glow-amber",
  },
  {
    icon: TrendingUp,
    label: "Predict Failures",
    description: "Forecast potential component failures",
    color: "destructive",
  },
  {
    icon: Wrench,
    label: "Create Work Orders",
    description: "Auto-generate maintenance work orders",
    color: "glow-emerald",
  },
]

const sampleMessages = [
  {
    role: "assistant",
    content: "Good morning! I've completed the overnight analysis of your BESS system. Here's what I found:\n\n• 3 containers show early degradation patterns\n• System efficiency improved by 1.2% after yesterday's calibration\n• 2 scheduled maintenance tasks are due this week\n\nWould you like me to elaborate on any of these findings?",
    timestamp: "8:00 AM",
  },
  {
    role: "user",
    content: "Tell me more about the containers with degradation patterns",
    timestamp: "8:05 AM",
  },
  {
    role: "assistant",
    content: "Based on my analysis, containers C-087, C-023, and C-134 are showing early signs of capacity degradation:\n\n**C-087 (High Priority)**\n• SOH: 82.3% (↓2.1% last month)\n• Predicted RUL: 18 months\n• Recommendation: Schedule cell balancing\n\n**C-023 (Medium Priority)**\n• SOH: 85.1% (↓1.4% last month)\n• Predicted RUL: 24 months\n• Recommendation: Monitor closely\n\n**C-134 (Low Priority)**\n• SOH: 88.7% (↓0.8% last month)\n• Predicted RUL: 30 months\n• Recommendation: Standard maintenance",
    timestamp: "8:05 AM",
  },
]

export function AICopilot() {
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return
    // Simulate sending
    setIsTyping(true)
    setTimeout(() => setIsTyping(false), 2000)
    setInput("")
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.7 }}
      className="glass rounded-2xl p-6 border border-glass-border"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <motion.div
            className="p-2.5 rounded-xl bg-gradient-to-br from-glow-purple/20 to-primary/20 border border-glow-purple/30"
            animate={{
              boxShadow: [
                "0 0 0 0 rgba(139, 92, 246, 0)",
                "0 0 20px 5px rgba(139, 92, 246, 0.2)",
                "0 0 0 0 rgba(139, 92, 246, 0)",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Bot className="w-6 h-6 text-glow-purple" />
          </motion.div>
          <div>
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              AI Copilot
              <span className="px-2 py-0.5 text-xs rounded-full bg-glow-emerald/10 text-glow-emerald border border-glow-emerald/30">
                Online
              </span>
            </h2>
            <p className="text-sm text-muted-foreground">Intelligent operations assistant</p>
          </div>
        </div>
        <motion.div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-glow-purple/10 border border-glow-purple/30"
          whileHover={{ scale: 1.05 }}
        >
          <Sparkles className="w-4 h-4 text-glow-purple" />
          <span className="text-xs font-medium text-glow-purple">GPT-4 Turbo</span>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Quick Actions</h3>
          {quickActions.map((action, index) => {
            const Icon = action.icon
            return (
              <motion.button
                key={action.label}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ scale: 1.02, x: 4 }}
                whileTap={{ scale: 0.98 }}
                className={`
                  w-full flex items-center gap-3 p-3 rounded-xl
                  bg-secondary/30 border border-border/50
                  hover:bg-${action.color}/5 hover:border-${action.color}/30
                  transition-smooth text-left group
                `}
              >
                <div className={`p-2 rounded-lg bg-${action.color}/10 border border-${action.color}/30 group-hover:bg-${action.color}/20 transition-colors`}>
                  <Icon className={`w-4 h-4 text-${action.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{action.label}</p>
                  <p className="text-xs text-muted-foreground truncate">{action.description}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
              </motion.button>
            )
          })}
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2 flex flex-col h-[400px]">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
            {sampleMessages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`
                    max-w-[85%] p-4 rounded-2xl
                    ${message.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-md"
                      : "bg-secondary/50 border border-border/50 rounded-bl-md"
                    }
                  `}
                >
                  {message.role === "assistant" && (
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-glow-purple" />
                      <span className="text-xs font-medium text-glow-purple">AI Copilot</span>
                      <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                    </div>
                  )}
                  <div className="text-sm whitespace-pre-wrap leading-relaxed">
                    {message.content}
                  </div>
                  {message.role === "user" && (
                    <div className="text-xs text-primary-foreground/70 mt-1 text-right">
                      {message.timestamp}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            
            {/* Typing Indicator */}
            <AnimatePresence>
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="flex items-center gap-2 p-4 rounded-2xl rounded-bl-md bg-secondary/50 border border-border/50 max-w-[85%]"
                >
                  <Sparkles className="w-4 h-4 text-glow-purple" />
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ y: [0, -5, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="flex gap-3">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about system health, generate reports, analyze trends..."
              className="flex-1 bg-secondary/50 border-border/50 focus:border-primary/50"
            />
            <Button
              type="submit"
              disabled={!input.trim() || isTyping}
              className="bg-gradient-to-r from-primary to-glow-purple hover:opacity-90 transition-opacity"
            >
              {isTyping ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </form>
        </div>
      </div>
    </motion.div>
  )
}
